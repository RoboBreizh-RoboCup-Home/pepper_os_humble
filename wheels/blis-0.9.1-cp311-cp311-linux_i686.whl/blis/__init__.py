# Copyright (c) 2017 - 2022 ExplosionAI GmbH, released under BSD-3-Clause.

from .cy import init

init()
